# from .myfunctions import neliöjuuri, kuutiojuuri
from .myfunctions import *
