
# RKMATH

Easy to use math library with intuitive and familiar arithmatic operations and formulas.

Helppo käyttöinen intuitiivinen matikkakirjasto missä yleisimmät aritmaattisetoperaatiot ja kaavat.




## FAQ

#### How many functions does it have? / kuinka monta funktiota on mukana

Currently 14 but more are coming soon, Tällä hetkellä 14 mutta lisää on tulossa.

#### Who is it made for / kenelle se on tehty ?

General upper secondary school students and beginners, Lukiolaisille ja aloitteleville ohjelmoijille.




## Features
- small size
- supports PIP-package manager
- finnish functions
- Pieni koko
- Tukee PIP package manageria
- suomenkieliset laajennukset



## Installation

You can install the project by either, voit ladata projektin joko

```bash
pip install rkmath
```

or going to Download files > donwloading rkmath-0.1.0.tar.gz or the latest version. 

Tai menemällä latauksiin > ja lataamalla rkmath-0.1.0.tar.gz tai uusin versio.

## 🔗 Links
[![portfolio](https://img.shields.io/badge/my_portfolio-000?style=for-the-badge&logo=ko-fi&logoColor=white)](https://swifterhtmler.github.io/Portfolio/)

## Badges


[![MIT License](https://img.shields.io/badge/License-MIT-green.svg)](https://github.com/Swifterhtmler/RKmath/blob/main/LICENSE)
